// ══════════════════════════════════════════════════════
// הוסף את זה ל-db.js — בתוך db.serialize():
// ══════════════════════════════════════════════════════

db.run(`CREATE TABLE IF NOT EXISTS exhibitions_text (
  id INTEGER PRIMARY KEY DEFAULT 1,
  content_he TEXT DEFAULT '',
  content_en TEXT DEFAULT '',
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
)`);
db.run(`INSERT OR IGNORE INTO exhibitions_text (id, content_he, content_en) VALUES (1, '', '')`);


// ══════════════════════════════════════════════════════
// עדכן את route הציבורי של exhibitions ב-server.js:
// ══════════════════════════════════════════════════════

app.get(['/:lang(he|en)/exhibitions', '/exhibitions'], (req, res) => {
  const lang = req.params.lang || 'he';
  db.all("SELECT * FROM paintings WHERE category = 'exhibitions' ORDER BY sort_order ASC, id ASC", [], (err, rows) => {
    db.get('SELECT * FROM exhibitions_text WHERE id = 1', [], (err2, exContent) => {
      res.render('exhibitions', { lang, paintings: rows || [], exContent: exContent || { content_he: '', content_en: '' } });
    });
  });
});


// ══════════════════════════════════════════════════════
// הוסף routes חדשים לניהול טקסט תערוכות ב-server.js:
// ══════════════════════════════════════════════════════

app.get('/admin/exhibitions-text', adminAuth, (req, res) => {
  db.get('SELECT * FROM exhibitions_text WHERE id = 1', [], (err, row) => {
    res.render('admin/exhibitions-text', {
      lang: 'he',
      exContent: row || { content_he: '', content_en: '' },
      saved: req.query.saved === '1'
    });
  });
});

app.post('/admin/exhibitions-text', adminAuth, (req, res) => {
  const { content_he, content_en } = req.body;
  db.run(
    'UPDATE exhibitions_text SET content_he=?, content_en=?, updated_at=CURRENT_TIMESTAMP WHERE id=1',
    [content_he, content_en],
    () => res.redirect('/admin/exhibitions-text?saved=1')
  );
});
